<?php

// put full path to Smarty.class.php
require('C:/Users/TestUser/xampp/htdocs/Travel/lib/Smarty/libs/Smarty.class.php');
$smarty = new Smarty();


$smarty->display('login.tpl');

?>