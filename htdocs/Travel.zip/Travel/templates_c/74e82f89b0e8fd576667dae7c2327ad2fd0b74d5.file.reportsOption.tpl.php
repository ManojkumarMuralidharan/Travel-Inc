<?php /* Smarty version Smarty-3.1.8, created on 2012-05-21 15:55:52
         compiled from ".\templates\reportsOption.tpl" */ ?>
<?php /*%%SmartyHeaderCode:160234fb66dfb4038d9-46185308%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '74e82f89b0e8fd576667dae7c2327ad2fd0b74d5' => 
    array (
      0 => '.\\templates\\reportsOption.tpl',
      1 => 1337608465,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '160234fb66dfb4038d9-46185308',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4fb66dfb407304_75826798',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fb66dfb407304_75826798')) {function content_4fb66dfb407304_75826798($_smarty_tpl) {?><form action="" method="post" style="display:block;" id="reportsOption" class="niceform"><!--Start of monthly form -->
         
             
                   
                    
                    <script>
						
					
					</script>
                    
					 <table style="padding-left:120px";>
					 <tr>
					 <td>Report Type</td>
					 <td>
					 <table>
					 <tr>
					 <td><label class="check_label">Regular</label></td>
					 <td><div style="padding-left:30px;margin-top:-10px;" class="NFRadio NFh" id="1" onclick="changeReport('1');" id="1"  style="left: 279px; top: 187px; "></div></td>
					 <td><label style="padding-left:30px;" class="check_label">Monthly</label>	</td>
					 <td><div style="padding-left:30px;margin-top:-10px;" class="NFRadio" id="2" style="left: 355px; top: 187px; "  onclick="changeReport('2');"></div></td>
					 </tr>
					 </table>
							
					        
																		
                           
                
					 </td>
					 </tr>

					 </table>
                   
                    
           
                
         </form><!--End of monthly form --><?php }} ?>