	<div id="credits">
  <p>
  Brought to you by:
  </p>
	<ul>
	  <li><a href="http://math.nist.gov/">National Institute of Standards and Technology</a></li>
	  <li><a href="http://math.nist.gov/">MathWorks</a></li>
	  <li><a href="http://math.nist.gov/javanumerics/jama/">JAMA : A Java Matrix Package</a></li>	
	  <li>Paul Meagher</li>
	  <li>Michael Bommarito</li>
	  <li>Lukasz Karapuda</li>
	  <li>Bartek Matosiuk</li>
	</ul>
	</div>
